var film = [
    {
    titolo: "Star Wars - L'impero colpisce ancora",
    durata: 160,
    anno: 1980,
    genere: "Fantascienza",
    attori: ["Mark Hamill","Carrie Fisher"],
    locandina: "https://pad.mymovies.it/filmclub/2006/08/349/locandina.jpg"
    },
    {
        titolo: "Quei bravi ragazzi",
        durata: 120,
        anno: 1970,
        genere: "Thriller",
        attori: ["Mark Hamill","Carrie Fisher"],
        locandina: "https://pad.mymovies.it/filmclub/2006/08/252/locandina.jpg"
    },
    {
        titolo: "Per un pugno di dollari",
        durata: 160,
        anno: 1980,
        genere: "Economia",
        attori: ["Mark Hamill","Carrie Fisher"],
        locandina: "https://pad.mymovies.it/filmclub/2006/08/252/locandina.jpg"
    }
]